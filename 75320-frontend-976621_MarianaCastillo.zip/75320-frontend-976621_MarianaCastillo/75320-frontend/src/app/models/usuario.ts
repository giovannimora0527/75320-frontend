export class Usuario {
    id?: number;   
    
}