export class Paciente {
  id!: number;
  tipoDocumento!: string;
  numeroDocumento!: string;
  nombres!: string;
  apellidos!: string;
  telefono!: string;
  correo!: string;
  direccion!: string;
  fechaNacimiento!: string; // "1995-07-20"
}
