export class Especializacion {
  id!: number;
  nombre!: string;
  descripcion!: string;
  codigoEspecializacion!: string;
}
