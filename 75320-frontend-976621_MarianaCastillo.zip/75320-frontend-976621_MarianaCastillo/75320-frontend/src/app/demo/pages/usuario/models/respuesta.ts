export class RespuestaRs {
    message!: string;
    status!: number;
}