export class Usuario {
    id: number;
    username: string;
    password: string;
    rol: string;
    fechaCreacion: string;
    activo: boolean;    
}