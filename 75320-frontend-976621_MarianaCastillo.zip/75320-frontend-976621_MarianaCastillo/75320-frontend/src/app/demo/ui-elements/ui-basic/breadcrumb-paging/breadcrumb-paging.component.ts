import { Component } from '@angular/core';

@Component({
  selector: 'app-breadcrumb-paging',
  standalone: true,
  imports: [],
  templateUrl: './breadcrumb-paging.component.html',
  styleUrls: ['./breadcrumb-paging.component.scss']
})
export default class BreadcrumbPagingComponent {}
